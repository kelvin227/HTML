<?php

$host="localhost";
$user="root";
$password="";
$db="gatordb";

$data=mysqli_connect($host,$user,$password,$db);
